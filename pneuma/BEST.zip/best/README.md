# PNEUMA — best renders (rolling window)

Curated best-of from the cart-theatre build. Every image is rendered from
committed, reproducible state at the blend sha256 named in MANIFEST.md —
no staging-only scene the build cannot reproduce, no upscale.

Producer-selected views. Independent non-owner acceptance remains PENDING.

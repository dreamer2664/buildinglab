# MANIFEST — best-renders-pneuma

One row per render: stage, subject, timestamp, source-file sha256, gate status at capture.

The PNG masters live in the lane at `renders/best/`; the copies in this zip are
JPEG derivatives at quality ≤92, long edge 2560 px, ≤4 MB each (D-007).

| file in this zip | master | stage | subject | rendered (UTC) | engine | res | source blend sha256 | image sha256 | gate status |
|---|---|---|---|---|---|---|---|---|---|
| cart_rear.jpg | cart_rear.png | B | cart_rear | 2026-10-21T19:18:17Z | CYCLES | 2560x1440 | b2f704a04c70d219 | 5706f9c637cbe0c8 | G9 pending |
| cart_side.jpg | cart_side.png | B | cart_side | 2026-10-21T19:14:24Z | CYCLES | 2560x1440 | b2f704a04c70d219 | 9eff94f130214b1b | G9 pending |
| drum_threequarter.jpg | drum_threequarter.png | B | drum_threequarter | 2026-10-21T19:21:58Z | CYCLES | 2560x1440 | b2f704a04c70d219 | d02c5f839dc15b6c | G9 pending |
| grain_flow.jpg | grain_flow.png | B | grain_flow | 2026-10-21T19:27:10Z | CYCLES | 2560x1440 | b2f704a04c70d219 | 1d0c474607915616 | G9 pending |
| hopper_above.jpg | hopper_above.png | B | hopper_above | 2026-10-21T19:10:56Z | CYCLES | 2560x1440 | b2f704a04c70d219 | 303b72e6d5ef445d | G9 pending |
| hopper_orifice.jpg | hopper_orifice.png | B | hopper_orifice | 2026-10-21T19:05:56Z | CYCLES | 2560x1440 | b2f704a04c70d219 | d61e15e3c8bb5ff6 | G9 pending |
| hopper_threequarter.jpg | hopper_threequarter.png | B | hopper_threequarter | 2026-10-21T19:00:41Z | CYCLES | 2560x1440 | b2f704a04c70d219 | 6e217b416cc95dae | G9 pending |
| machine_wide.jpg | machine_wide.png | B | machine_wide | 2026-10-21T19:30:50Z | CYCLES | 2560x1440 | b2f704a04c70d219 | 8298b3099019fbe1 | G9 pending |
